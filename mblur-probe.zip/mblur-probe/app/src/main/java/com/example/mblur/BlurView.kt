package com.example.mblur

import android.content.Context
import android.graphics.*
import android.view.SurfaceControl
import android.view.View
import kotlin.math.hypot

// Desfoque direcional (AGSL) ao longo do movimento; so aparece enquanto ha movimento
class BlurView(c: Context) : View(c) {
    private val rt = RuntimeShader(
        """
        uniform shader img;
        uniform float2 dir;
        half4 main(float2 c) {
            half4 s = half4(0.0);
            for (int i = 0; i < 16; i++) {
                float t = float(i) / 15.0 - 0.5;
                s += img.eval(c + dir * t);
            }
            return s / 16.0;
        }
        """.trimIndent()
    )
    private val paint = Paint()
    private var bmp: Bitmap? = null
    private var dx = 0f
    private var dy = 0f
    private val skipper = object : Runnable {
        override fun run() { skipCapture(); postDelayed(this, 2000) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); alpha = 0f; postDelayed(skipper, 300) }
    override fun onDetachedFromWindow() { removeCallbacks(skipper); super.onDetachedFromWindow() }

    fun update(b: Bitmap?, x: Float, y: Float, show: Boolean) {
        post {
            if (b != null) { bmp?.recycle(); bmp = b }
            else if (!show) { bmp?.recycle(); bmp = null }
            val len = hypot(x, y)
            val f = if (len > 240f) 240f / len else 1f
            dx = x * f; dy = y * f
            alpha = if (show && bmp != null) 1f else 0f
            invalidate()
        }
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        sh.setLocalMatrix(Matrix().apply { setScale(width.toFloat() / b.width, height.toFloat() / b.height) })
        rt.setInputShader("img", sh)
        rt.setFloatUniform("dir", dx, dy)
        paint.shader = rt
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun skipCapture() {
        try {
            val vri = View::class.java.getMethod("getViewRootImpl").invoke(this) ?: return
            val sc = vri.javaClass.getMethod("getSurfaceControl").invoke(vri) as SurfaceControl
            val tx = SurfaceControl.Transaction()
            SurfaceControl.Transaction::class.java
                .getMethod("setSkipScreenshot", SurfaceControl::class.java, Boolean::class.javaPrimitiveType)
                .invoke(tx, sc, true)
            tx.apply()
        } catch (_: Throwable) {}
    }
}
