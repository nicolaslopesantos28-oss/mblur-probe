package com.example.mblur

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var msg: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("p", 0)
        msg = TextView(this).apply { textSize = 15f; setTextIsSelectable(true); text = "Força do borrão: ${prefs.getInt("n", 3) - 1}/5" }
        val seek = SeekBar(this).apply {
            max = 4; progress = prefs.getInt("n", 3) - 2
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    prefs.edit().putInt("n", p + 2).apply()
                    msg.text = "Força do borrão: ${p + 1}/5 (religue para aplicar)"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 120, 40, 40)
            addView(btn("1. Permitir sobreposição") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            addView(btn("2. Ligar") { ligar() })
            addView(btn("Desligar") { stopService(Intent(this@MainActivity, BlurService::class.java)) })
            addView(btn("Ver erro completo") { msg.text = prefs.getString("err", "sem erro") })
            addView(seek); addView(msg)
        }
        setContentView(ScrollView(this).apply { addView(col) })
        Shizuku.addRequestPermissionResultListener { _, r -> if (r == PackageManager.PERMISSION_GRANTED) ligar() }
    }

    private fun ligar() {
        if (!Settings.canDrawOverlays(this)) { msg.text = "Falta o passo 1 (sobreposição)."; return }
        if (!Shizuku.pingBinder()) { msg.text = "Shizuku não está rodando. Abra o Shizuku e inicie."; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(1); return }
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        startForegroundService(Intent(this, BlurService::class.java))
        msg.text = "Ligado. Se algo falhar, aparece um aviso."
    }
}
