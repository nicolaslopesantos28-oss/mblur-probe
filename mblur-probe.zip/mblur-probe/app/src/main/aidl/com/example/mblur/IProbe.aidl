package com.example.mblur;
interface IProbe {
    void destroy() = 16777114;
    String probe() = 1;
}
