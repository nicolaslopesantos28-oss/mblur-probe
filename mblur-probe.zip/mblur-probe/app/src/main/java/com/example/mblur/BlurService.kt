package com.example.mblur

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.HardwareBuffer
import android.os.*
import android.view.*
import android.widget.Toast
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku

class BlurService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private var view: BlurView? = null
    private var remote: IBlur? = null
    @Volatile private var running = false

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, BlurImpl::class.java.name))
            .processNameSuffix("blur").daemon(false).version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            remote = IBlur.Stub.asInterface(b)
            ui.post { addOverlay() }
            loop()
        }
        override fun onServiceDisconnected(n: ComponentName?) { running = false }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("blur", "Motion Blur", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "blur")
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Motion Blur ligado").build())
        if (remote == null) {
            HiddenApiBypass.addHiddenApiExemptions("L")
            Shizuku.bindUserService(args, conn)
        }
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val n = getSharedPreferences("p", 0).getInt("n", 3)
        val v = BlurView(this, n)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        getSystemService(WindowManager::class.java).addView(v, lp)
        view = v
    }

    private fun loop() {
        running = true
        Thread {
            try {
                while (running) {
                    val b = remote!!.capture()
                    b.classLoader = HardwareBuffer::class.java.classLoader
                    val hb = b.getParcelable<HardwareBuffer>("b") ?: continue
                    val bmp = Bitmap.wrapHardwareBuffer(hb, ColorSpace.get(ColorSpace.Named.SRGB))
                    hb.close()
                    if (bmp != null) view?.push(bmp)
                }
            } catch (e: Throwable) {
                ui.post {
                    Toast.makeText(this, "Erro: ${e.cause ?: e}", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        view?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Throwable) {} }
        try { remote?.destroy() } catch (_: Throwable) {}
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
