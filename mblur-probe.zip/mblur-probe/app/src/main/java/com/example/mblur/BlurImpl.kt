package com.example.mblur

import android.hardware.HardwareBuffer
import android.os.Bundle
import android.os.IBinder
import java.io.File
import java.lang.reflect.Method
import kotlin.system.exitProcess

// Roda como "shell" via Shizuku: captura a tela inteira
class BlurImpl : IBlur.Stub() {
    private var cap: Method? = null
    private var args: Any? = null
    private var last: HardwareBuffer? = null
    private val BLD = "android.window.ScreenCapture\$DisplayCaptureArgs\$Builder"
    private val dirs = listOf("/system/framework", "/system_ext/framework", "/system/system_ext/framework", "/product/framework")

    override fun destroy() { exitProcess(0) }

    override fun capture(): Bundle {
        if (cap == null) init()
        last?.close()
        val res = cap!!.invoke(null, args)!!
        val hb = res.javaClass.getMethod("getHardwareBuffer").invoke(res) as HardwareBuffer
        last = hb
        return Bundle().apply { putParcelable("b", hb) }
    }

    private fun init() {
        val sc = Class.forName("android.window.ScreenCapture")
        val bld = Class.forName(BLD)
        val id = physId()
        val builder = try {
            bld.getConstructor(Long::class.javaPrimitiveType).newInstance(id)
        } catch (e: NoSuchMethodException) {
            bld.getConstructor(IBinder::class.java).newInstance(token(id))
        }
        val build = builder.javaClass.getMethod("build"); build.isAccessible = true
        args = build.invoke(builder)
        cap = sc.declaredMethods.first { it.name == "captureDisplay" && it.parameterTypes.size == 1 }
        cap!!.isAccessible = true
    }

    private fun physId(): Long {
        val dmg = Class.forName("android.hardware.display.DisplayManagerGlobal").getMethod("getInstance").invoke(null)!!
        val info = dmg.javaClass.getMethod("getDisplayInfo", Int::class.javaPrimitiveType).invoke(dmg, 0)!!
        val addr = info.javaClass.getField("address").get(info)!!
        return addr.javaClass.getMethod("getPhysicalDisplayId").invoke(addr) as Long
    }

    private fun token(id: Long): IBinder {
        val errs = StringBuilder()
        val s = Class.forName("android.view.SurfaceControl")
        for (n in listOf("getPhysicalDisplayToken", "getInternalDisplayToken", "getBuiltInDisplay")) {
            try {
                val m = s.declaredMethods.first { it.name == n }
                m.isAccessible = true
                val r = when (m.parameterTypes.size) { 0 -> m.invoke(null); else -> m.invoke(null, if (m.parameterTypes[0] == Long::class.javaPrimitiveType) id else 0) }
                return r as IBinder
            } catch (e: Throwable) { errs.append("SC.$n: ${e.javaClass.simpleName}\n") }
        }
        try {
            val dc = findDisplayControl() ?: throw ClassNotFoundException("DisplayControl nao achada")
            val load = Runtime::class.java.getDeclaredMethod("loadLibrary0", Class::class.java, String::class.java)
            load.isAccessible = true
            load.invoke(Runtime.getRuntime(), dc, "android_servers")
            return dc.getMethod("getPhysicalDisplayToken", Long::class.javaPrimitiveType).invoke(null, id) as IBinder
        } catch (e: Throwable) { errs.append("DisplayControl: ${e.cause ?: e}\n") }
        throw IllegalStateException("Sem token de tela.\n$errs\nBuilder: " +
            Class.forName(BLD).constructors.joinToString { "(" + it.parameterTypes.joinToString { p -> p.simpleName } + ")" } +
            "\nSC metodos: " + s.declaredMethods.map { it.name }.filter { it.contains("isplay") }.distinct() +
            "\nJars: " + dirs.map { d -> File(d).listFiles()?.count { it.name.endsWith(".jar") } ?: -1 })
    }

    private fun findDisplayControl(): Class<*>? {
        val names = listOf("com.android.server.display.DisplayControl", "android.view.DisplayControl")
        for (n in names) try { return Class.forName(n) } catch (_: Throwable) {}
        try {
            val factory = Class.forName("com.android.internal.os.ClassLoaderFactory")
            val create = factory.getDeclaredMethod(
                "createClassLoader", String::class.java, String::class.java, String::class.java,
                ClassLoader::class.java, Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType, String::class.java)
            val loader = create.invoke(null, "/system/framework/services.jar", null, null,
                ClassLoader.getSystemClassLoader(), 0, true, null) as ClassLoader
            for (n in names) try { return loader.loadClass(n) } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        for (d in dirs) File(d).listFiles { f -> f.name.endsWith(".jar") }?.forEach { jar ->
            val l = dalvik.system.PathClassLoader(jar.path, ClassLoader.getSystemClassLoader())
            for (n in names) try { return l.loadClass(n) } catch (_: Throwable) {}
        }
        return null
    }
}
