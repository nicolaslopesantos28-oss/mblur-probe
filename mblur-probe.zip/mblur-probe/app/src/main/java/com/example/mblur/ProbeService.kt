package com.example.mblur

import android.os.IBinder
import kotlin.system.exitProcess

// Teste 2: pega o token da tela via DisplayControl (services.jar) e mede a captura
class ProbeService : IProbe.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun probe(): String {
        val sb = StringBuilder("Teste 2 - Android ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})\n\n")
        sb.append(sig("android.view.SurfaceControl\$Transaction", "setSkipScreenshot"))
        sb.append(sig("android.window.ScreenCapture", "captureLayersExcluding"))
        sb.append(sig("android.window.ScreenCapture", "captureDisplay"))
        sb.append("\n").append(captureTest())
        return sb.toString()
    }

    private fun sig(cls: String, name: String): String = try {
        Class.forName(cls).declaredMethods.filter { it.name == name }
            .joinToString("") { "$name(${it.parameterTypes.joinToString { p -> p.simpleName }})\n" }
    } catch (e: Throwable) { "$cls: $e\n" }

    private fun displayToken(): IBinder {
        val factory = Class.forName("com.android.internal.os.ClassLoaderFactory")
        val create = factory.getDeclaredMethod(
            "createClassLoader", String::class.java, String::class.java, String::class.java,
            ClassLoader::class.java, Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType, String::class.java
        )
        val loader = create.invoke(null, "/system/framework/services.jar", null, null,
            ClassLoader.getSystemClassLoader(), 0, true, null) as ClassLoader
        val dc = loader.loadClass("android.view.DisplayControl")
        val load = Runtime::class.java.getDeclaredMethod("loadLibrary0", Class::class.java, String::class.java)
        load.isAccessible = true
        load.invoke(Runtime.getRuntime(), dc, "android_servers")
        val ids = dc.getMethod("getPhysicalDisplayIds").invoke(null) as LongArray
        return dc.getMethod("getPhysicalDisplayToken", Long::class.javaPrimitiveType).invoke(null, ids[0]) as IBinder
    }

    private fun captureTest(): String = try {
        val token = displayToken()
        val sc = Class.forName("android.window.ScreenCapture")
        val builder = Class.forName("android.window.ScreenCapture\$DisplayCaptureArgs\$Builder")
            .getConstructor(IBinder::class.java).newInstance(token)
        val build = builder.javaClass.getMethod("build"); build.isAccessible = true
        val args = build.invoke(builder)
        val cap = sc.declaredMethods.first { it.name == "captureDisplay" && it.parameterTypes.size == 1 }
        cap.isAccessible = true
        var w = 0; var h = 0
        val t0 = System.nanoTime()
        repeat(30) {
            val res = cap.invoke(null, args)!!
            val getBuf = res.javaClass.getMethod("getHardwareBuffer")
            val buf = getBuf.invoke(res) as android.hardware.HardwareBuffer
            w = buf.width; h = buf.height; buf.close()
        }
        val avg = (System.nanoTime() - t0) / 30 / 1_000_000.0
        "CAPTURA OK ${w}x${h}, media %.1f ms por quadro".format(avg)
    } catch (e: Throwable) { "CAPTURA FALHOU -> ${e.cause ?: e}" }
}
