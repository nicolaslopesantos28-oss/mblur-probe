package com.example.mblur

import android.hardware.HardwareBuffer
import android.os.Bundle
import android.os.IBinder
import java.lang.reflect.Method
import kotlin.system.exitProcess

// Roda como "shell" via Shizuku: captura a tela inteira
class BlurImpl : IBlur.Stub() {
    private var cap: Method? = null
    private var args: Any? = null
    private var last: HardwareBuffer? = null

    override fun destroy() { exitProcess(0) }

    override fun capture(): Bundle {
        if (cap == null) init()
        last?.close()
        val res = cap!!.invoke(null, args)!!
        val hb = res.javaClass.getMethod("getHardwareBuffer").invoke(res) as HardwareBuffer
        last = hb
        return Bundle().apply { putParcelable("b", hb) }
    }

    private fun init() {
        val sc = Class.forName("android.window.ScreenCapture")
        val bld = Class.forName("android.window.ScreenCapture\$DisplayCaptureArgs\$Builder")
        val id = physId()
        val builder = try {
            bld.getConstructor(Long::class.javaPrimitiveType).newInstance(id)
        } catch (e: NoSuchMethodException) {
            bld.getConstructor(IBinder::class.java).newInstance(token(id))
        }
        val build = builder.javaClass.getMethod("build"); build.isAccessible = true
        args = build.invoke(builder)
        cap = sc.declaredMethods.first { it.name == "captureDisplay" && it.parameterTypes.size == 1 }
        cap!!.isAccessible = true
    }

    private fun physId(): Long {
        val dmg = Class.forName("android.hardware.display.DisplayManagerGlobal").getMethod("getInstance").invoke(null)!!
        val info = dmg.javaClass.getMethod("getDisplayInfo", Int::class.javaPrimitiveType).invoke(dmg, 0)!!
        val addr = info.javaClass.getField("address").get(info)!!
        return addr.javaClass.getMethod("getPhysicalDisplayId").invoke(addr) as Long
    }

    private fun token(id: Long): IBinder {
        val s = Class.forName("android.view.SurfaceControl")
        for (n in listOf("getPhysicalDisplayToken", "getInternalDisplayToken")) {
            try {
                val m = s.declaredMethods.first { it.name == n }
                return (if (m.parameterTypes.isEmpty()) m.invoke(null) else m.invoke(null, id)) as IBinder
            } catch (_: Throwable) {}
        }
        throw IllegalStateException("Sem metodo de token de tela nesta ROM")
    }
}
