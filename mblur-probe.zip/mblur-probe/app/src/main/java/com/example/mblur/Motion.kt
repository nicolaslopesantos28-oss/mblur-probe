package com.example.mblur

import android.graphics.Bitmap
import kotlin.math.abs

// Estima quanto a tela deslocou entre dois quadros (rolagem/arrasto), comparando perfis de linhas e colunas
class Motion {
    private var pr: FloatArray? = null
    private var pc: FloatArray? = null
    private var sx = 0f
    private var sy = 0f

    fun update(bm: Bitmap, scale: Float): FloatArray {
        val w = bm.width; val h = bm.height
        val sw = bm.copy(Bitmap.Config.ARGB_8888, false)
        val px = IntArray(w * h); sw.getPixels(px, 0, w, 0, 0, w, h); sw.recycle()
        val rows = FloatArray(h); val cols = FloatArray(w)
        for (y in 0 until h) for (x in 0 until w) {
            val p = px[y * w + x]
            val l = (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10f
            rows[y] += l; cols[x] += l
        }
        for (y in 0 until h) rows[y] /= w
        for (x in 0 until w) cols[x] /= h
        var dy = 0f; var dx = 0f
        pr?.let { dy = shift(rows, it) }
        pc?.let { dx = shift(cols, it) }
        pr = rows; pc = cols
        sx = 0.5f * sx + 0.5f * dx * scale
        sy = 0.5f * sy + 0.5f * dy * scale
        return floatArrayOf(sx, sy)
    }

    private fun shift(a: FloatArray, b: FloatArray): Float {
        val n = a.size; val r = minOf(n / 4, 40)
        var best = 0; var bestE = Float.MAX_VALUE; var e0 = 0f
        for (s in -r..r) {
            var e = 0f; var c = 0
            for (i in maxOf(0, s) until minOf(n, n + s)) { e += abs(a[i] - b[i - s]); c++ }
            if (c == 0) continue
            e /= c
            if (s == 0) e0 = e
            if (e < bestE) { bestE = e; best = s }
        }
        return if (best != 0 && bestE < e0 * 0.7f && e0 > 1.0f) best.toFloat() else 0f
    }
}
