package com.example.mblur;
interface IBlur {
    void destroy() = 16777114;
    android.os.Bundle capture() = 1;
}
