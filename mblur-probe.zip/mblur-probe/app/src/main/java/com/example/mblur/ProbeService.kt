package com.example.mblur

import android.os.IBinder
import kotlin.system.exitProcess

// Roda no processo "shell" via Shizuku
class ProbeService : IProbe.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun probe(): String {
        val sb = StringBuilder("Android ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})\n\n")
        val classes = listOf(
            "android.view.SurfaceControl", "android.view.SurfaceControl\$DisplayCaptureArgs",
            "android.view.SurfaceControl\$LayerCaptureArgs", "android.view.SurfaceControl\$Transaction",
            "android.window.ScreenCapture", "android.window.ScreenCapture\$DisplayCaptureArgs",
            "android.window.ScreenCapture\$LayerCaptureArgs", "android.view.DisplayControl"
        )
        for (n in classes) {
            try {
                val m = Class.forName(n).declaredMethods.map { it.name }
                    .filter { x -> listOf("apture", "xclude", "kip", "DisplayToken", "PhysicalDisplay").any { x.contains(it) } }.distinct()
                sb.append("OK  $n $m\n")
            } catch (e: Throwable) { sb.append("--  $n\n") }
        }
        sb.append("\n").append(capture("android.view.SurfaceControl")).append("\n")
        sb.append(capture("android.window.ScreenCapture")).append("\n")
        return sb.toString()
    }

    private fun capture(owner: String): String = try {
        val token = Class.forName("android.view.SurfaceControl")
            .getMethod("getInternalDisplayToken").invoke(null) as IBinder
        val o = Class.forName(owner)
        val argsCls = Class.forName("$owner\$DisplayCaptureArgs")
        val builder = Class.forName("$owner\$DisplayCaptureArgs\$Builder")
            .getConstructor(IBinder::class.java).newInstance(token)
        val args = builder.javaClass.getMethod("build").invoke(builder)
        val t0 = System.nanoTime()
        val res = o.getMethod("captureDisplay", argsCls).invoke(null, args)
        val buf = res!!.javaClass.getMethod("getHardwareBuffer").invoke(res) as android.hardware.HardwareBuffer
        "CAPTURA $owner: OK ${buf.width}x${buf.height} em ${(System.nanoTime() - t0) / 1_000_000} ms"
    } catch (e: Throwable) { "CAPTURA $owner: FALHOU -> ${e.cause ?: e}" }
}
