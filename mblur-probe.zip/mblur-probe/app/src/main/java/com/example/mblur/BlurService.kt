package com.example.mblur

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.HardwareBuffer
import android.os.*
import android.view.*
import android.widget.Toast
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku

class BlurService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private var view: BlurView? = null
    private var remote: IBlur? = null
    @Volatile private var running = false

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, BlurImpl::class.java.name))
            .processNameSuffix("blur").daemon(false).version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            remote = IBlur.Stub.asInterface(b)
            ui.post { addOverlay() }
            loop()
        }
        override fun onServiceDisconnected(n: ComponentName?) { running = false }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("blur", "Motion Blur", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "blur")
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Motion Blur ligado").build())
        if (remote == null) {
            HiddenApiBypass.addHiddenApiExemptions("L")
            Shizuku.bindUserService(args, conn)
        }
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val v = BlurView(this)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        getSystemService(WindowManager::class.java).addView(v, lp)
        view = v
    }

    private fun loop() {
        running = true
        val k = getSharedPreferences("p", 0).getInt("n", 3) / 3f
        val screenW = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds.width().toFloat()
        val srgb = ColorSpace.get(ColorSpace.Named.SRGB)
        Thread {
            val motion = Motion()
            var idle = 99
            try {
                while (running) {
                    val full = idle < 8
                    val b = remote!!.capture(full)
                    b.classLoader = HardwareBuffer::class.java.classLoader
                    val sb = b.getParcelable<HardwareBuffer>("s") ?: continue
                    val small = Bitmap.wrapHardwareBuffer(sb, srgb)
                    sb.close()
                    if (small == null) continue
                    val m = motion.update(small, screenW / small.width)
                    small.recycle()
                    if (Math.abs(m[0]) + Math.abs(m[1]) >= 1f) idle = 0 else idle++
                    val show = idle < 8
                    var fb: Bitmap? = null
                    if (full) {
                        val hb = b.getParcelable<HardwareBuffer>("b")
                        if (hb != null) { fb = Bitmap.wrapHardwareBuffer(hb, srgb); hb.close() }
                    }
                    view?.update(if (show) fb else null, m[0] * k, m[1] * k, show && fb != null)
                }
            } catch (e: Throwable) {
                getSharedPreferences("p", 0).edit().putString("err", (e.cause ?: e).toString()).apply()
                ui.post {
                    Toast.makeText(this, "Erro: ${e.cause ?: e}", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        view?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Throwable) {} }
        try { remote?.destroy() } catch (_: Throwable) {}
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
