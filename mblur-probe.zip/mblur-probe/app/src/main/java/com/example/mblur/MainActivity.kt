package com.example.mblur

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var out: TextView

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            val s = IProbe.Stub.asInterface(b)
            Thread {
                val r = try { s.probe() } catch (e: Throwable) { "Erro: $e" }
                runOnUiThread { out.text = r }
            }.start()
        }
        override fun onServiceDisconnected(n: ComponentName?) {}
    }

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, ProbeService::class.java.name))
            .processNameSuffix("probe").daemon(false).version(1)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        out = TextView(this).apply { setTextIsSelectable(true); textSize = 12f; text = "Toque em Rodar teste" }
        val btn = Button(this).apply { text = "Rodar teste"; setOnClickListener { run() } }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 96, 32, 32)
            addView(btn); addView(out)
        }
        setContentView(ScrollView(this).apply { addView(col) })
        Shizuku.addRequestPermissionResultListener { _, r -> if (r == PackageManager.PERMISSION_GRANTED) bind() }
    }

    private fun run() {
        if (!Shizuku.pingBinder()) { out.text = "Shizuku não está rodando. Abra o Shizuku e inicie o serviço."; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(1); return }
        bind()
    }

    private fun bind() { out.text = "Executando..."; Shizuku.bindUserService(args, conn) }
}
