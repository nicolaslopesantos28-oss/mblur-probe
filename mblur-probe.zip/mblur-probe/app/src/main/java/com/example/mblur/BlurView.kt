package com.example.mblur

import android.content.Context
import android.graphics.*
import android.view.SurfaceControl
import android.view.View

// Mistura os ultimos N quadros. Esconde a si mesma da captura (setSkipScreenshot)
class BlurView(c: Context, private val n: Int) : View(c) {
    private val frames = ArrayDeque<Bitmap>()
    private val paint = Paint()
    private var count = 0

    fun push(b: Bitmap) {
        synchronized(frames) {
            frames.addLast(b)
            while (frames.size > n) frames.removeFirst().recycle()
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        if (count++ % 120 == 0) skipCapture()
        val dst = Rect(0, 0, width, height)
        synchronized(frames) {
            frames.forEachIndexed { i, b ->
                if (!b.isRecycled) { paint.alpha = 255 / (i + 1); c.drawBitmap(b, null, dst, paint) }
            }
        }
    }

    private fun skipCapture() {
        try {
            val vri = View::class.java.getMethod("getViewRootImpl").invoke(this) ?: return
            val sc = vri.javaClass.getMethod("getSurfaceControl").invoke(vri) as SurfaceControl
            val tx = SurfaceControl.Transaction()
            SurfaceControl.Transaction::class.java
                .getMethod("setSkipScreenshot", SurfaceControl::class.java, Boolean::class.javaPrimitiveType)
                .invoke(tx, sc, true)
            tx.apply()
        } catch (_: Throwable) {}
    }
}
